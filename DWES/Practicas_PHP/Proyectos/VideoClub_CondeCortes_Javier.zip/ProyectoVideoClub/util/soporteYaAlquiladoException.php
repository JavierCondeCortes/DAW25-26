<?php
namespace Dwes\ProyectoVideoclub\Util;

class SoporteYaAlquiladoException extends VideoclubException {}
