<?php
namespace Dwes\ProyectoVideoclub\Util;

class VideoclubException extends \Exception {}
