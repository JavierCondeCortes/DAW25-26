<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

</head>

<body class=" ">
    <div class=" flex gap-1">
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class=" flex flex-col h-28 w-[25%] bg-slate-700 text-white pl-2 rounded-lg">
            <p><?php echo e($cliente->nombre); ?></p>
            <p><?php echo e($cliente->email); ?></p>
            <form class=" flex-grow content-center" action="<?php echo e(route('eliminar',$cliente->id)); ?>" method="post">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <input type="submit" value="Eliminar" class=" bg-red-500 text-white rounded-lg p-2">
            </form>
            <button type="submit" class=" bg-blue-500 text-white rounded-lg p-2" href="">Editar</button>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <a href="<?php echo e(route('page_crear')); ?>">crear</a>
</body>

</html><?php /**PATH C:\Users\MiNeClasero\Documents\_CLASES 2DAW\GitHubRepository\DAW25-26\DWES\Practicas_PHP\Proyectos\citas\resources\views/citas/clientes/lista_clientes.blade.php ENDPATH**/ ?>