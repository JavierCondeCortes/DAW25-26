<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo e(route('crearform')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p>el nombre es obligatorio</p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p>el correo no cumple las condiciones o existe</p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p>el telefono no cumple con con la cantidad de numeros</p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="">nombre</label>
        <input type="text" name="nombre" id="nombre">
        <label for="">email</label>
        <input type="text" name="email" id="email">
        <label for="">telefono</label>
        <input type="text" name="telefono" id="telefono">
        <label for="">activado</label>
        <input type="checkbox" name="activado" id="activado">
        <input type="submit" value="enviar">
    </form>
</body>
</html><?php /**PATH C:\Users\MiNeClasero\Documents\_CLASES 2DAW\GitHubRepository\DAW25-26\DWES\Practicas_PHP\Proyectos\citas\resources\views/citas/clientes/crear.blade.php ENDPATH**/ ?>