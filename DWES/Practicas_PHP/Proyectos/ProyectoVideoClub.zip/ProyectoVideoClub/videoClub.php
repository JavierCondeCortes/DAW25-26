<?php 
class videoClub{
    public function __construct(
        private int $nombre,
        private array $productos=[],
        private  int $numProductos,
        private array $socios=[],
        private int $numSocios,
    )
    {}
}
?>