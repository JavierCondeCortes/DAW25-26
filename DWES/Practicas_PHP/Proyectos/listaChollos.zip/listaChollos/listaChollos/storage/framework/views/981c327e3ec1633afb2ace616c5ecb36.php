<?php $__env->startSection('content'); ?>

<h1 class="with-full text-center text-7xl bg-gray-600 text-white pb-6">Lista de chollos</h1>

<a href="<?php echo e(route('crearChollo')); ?>" class="boton">crear chollo</a>


<form action="<?php echo e(route('filtro.categorias')); ?>" method="get">
    <select name="categoria_id" id="categoria" onchange="this.form.submit()">
        <option value="">Todas las categorías</option>

        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($categoria->id); ?>"
                <?php echo e(request('categoria_id') == $categoria->id ? 'selected' : ''); ?>>
                <?php echo e($categoria->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</form>


<div class="flex flex-wrap">
    <?php $__currentLoopData = $chollos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chollo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="border border-black bg-slate-200 rounded-xl m-10 w-1/5 h-[50vh] p-4 flex flex-col justify-between">

            <div class="w-full h-[33%] overflow-hidden">
                <img src="<?php echo e(asset($chollo->url)); ?>" alt="" class="w-full h-full object-cover">
            </div>

            <p class="text-center font-bold text-2xl">
                <?php echo e($chollo->titulo); ?>

            </p>

            <p>puntuacion: <?php echo e($chollo->puntuacion); ?></p>

            <p class="flex-shrink overflow-hidden">
                <?php echo e($chollo->descripcion); ?>

            </p>

            <div class="text-center font-semibold flex justify-around align-middle">
                <p class="basis-0">
                    Precio: <?php echo e($chollo->precio); ?> €
                </p>
                <p class="bg-gray-400 p-2 px-6 rounded-xl basis-0">
                    <a href="<?php echo e(route('detalles', ['id' => $chollo->id])); ?>">detalles</a>
                </p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php echo e($chollos->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('chollos.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\DAW25-26\DWES\Practicas_PHP\Proyectos\listaChollos\listaChollos\resources\views/chollos/index.blade.php ENDPATH**/ ?>