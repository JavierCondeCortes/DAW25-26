<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    
</head>

<?php $__env->startSection('content'); ?>

    <body class=" h-[100vh]">
        <?php if(session('catEliminada')): ?>
            <p><?php echo e(session('catEliminada')); ?></p>
        <?php endif; ?>
        <div class=" border-red-100 rounded-sm w-[40vw] h-[40vh] mx-auto my-auto ">
            <table>
                <tr class=" font-bold">
                    <td>ID:</td>
                    <td>Nombre:</td>
                    <td>Cantidad:</td>
                    <td>Accion:</td>
                </tr>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($categoria->id); ?></td>
                        <td><?php echo e($categoria->name); ?></td>
                        <td><?php echo e($categoria->chollos_count); ?></td>
                        <td><button><a href="<?php echo e(route('catElim', $categoria->id)); ?>">Emininar</a></button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <h2 class=" font-bold mt-5">Agregar nueva categoria</h2>
            <form action="<?php echo e(route('catCreate')); ?>" method="POST" class="flex">
                <?php echo csrf_field(); ?>
                <input type="text" name="name" class="mr-3">
                <button type="submit">Crear</button>
            </form>
        </div>
    </body>

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('chollos/navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\DAW25-26\DWES\Practicas_PHP\Proyectos\listaChollos\listaChollos\resources\views/chollos/listaCategorias.blade.php ENDPATH**/ ?>