<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    
</head>
<body>
    <?php $__env->startSection('content'); ?>
        
    <h1><?php echo e($chollo -> titulo); ?></h1>
    <p><?php echo e($chollo -> descripcion); ?></p>
    <p>precio sin descuento: <?php echo e($chollo -> precio); ?>€</p>
    <p>precio con descuento: <?php echo e($chollo -> precio_descuento); ?>€</p>
    <p>precio con descuento: <?php echo e($chollo -> categoria->name); ?></p>

    <button class=" bg-slate-700 p-2 rounded text-white hover:bg-slate-400 hover:text-black transition-all"> <a href="<?php echo e(route('inicio')); ?>">Inicio</a></button>
    <button class=" bg-slate-700 p-2 rounded text-white hover:bg-slate-400 hover:text-black transition-all"> <a href="<?php echo e(route('editar',['id' => $chollo->id])); ?>">Editar</a></button>
    <button class=" bg-slate-700 p-2 rounded text-white hover:bg-slate-400 hover:text-black transition-all"> <a href="<?php echo e(route('eliminar',['id' => $chollo->id])); ?>">Eliminar</a></button>
    
    <?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('chollos/navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\DAW25-26\DWES\Practicas_PHP\Proyectos\listaChollos\listaChollos\resources\views/chollos/detallesProducto.blade.php ENDPATH**/ ?>