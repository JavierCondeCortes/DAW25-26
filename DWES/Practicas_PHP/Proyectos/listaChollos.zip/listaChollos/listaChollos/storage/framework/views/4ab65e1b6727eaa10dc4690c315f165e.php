<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>


<?php $__env->startSection('content'); ?>

    <body>
        <form action="<?php echo e(route('actualizar', $chollo->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <h1 class=" text-3xl font-bold">Editar Chollo</h1>

            <label for="titulo">titulo</label>
            <input type="text" name="titulo" id="titulo" value="<?php echo e($chollo->titulo); ?>">

            <label for="descripcion">descripcion</label>
            <input type="text" name="descripcion" id="descripcion" value="<?php echo e($chollo->descripcion); ?>">

            <label for="url">url</label>
            <input type="file" name="url" id="url" value="<?php echo e($chollo->url); ?>">

            <label for="categoria">categoria</label>
            <input type="number" name="categoria_id" id="categoria" value="<?php echo e($chollo->categoria_id); ?>">

            <label for="puntuacion">puntuacion</label>
            <input type="number" name="puntuacion" id="puntuacion" value="<?php echo e($chollo->puntuacion); ?>">

            <label for="precio">precio de mercado</label>
            <input type="number" name="precio" id="precio" value="<?php echo e($chollo->precio); ?>">
            
            <label for="precioDescuento">precio descuento</label>
            <input type="number" name="precio_descuento" id="precioDescuento" value="<?php echo e($chollo->precio_descuento); ?>">

            <label for="disponible">disponible</label>
            <input type="number" name="disponible" id="disponible" value="<?php echo e($chollo->disponible); ?>">

            <input type="submit" value="editar" name="editar">
            <a href="<?php echo e(route('inicio')); ?>" class="boton">regresar</a>
        </form>
    </body>

<?php $__env->stopSection(); ?>

</html>

<?php echo $__env->make('chollos/navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\DAW25-26\DWES\Practicas_PHP\Proyectos\listaChollos\listaChollos\resources\views/chollos/editarChollo.blade.php ENDPATH**/ ?>