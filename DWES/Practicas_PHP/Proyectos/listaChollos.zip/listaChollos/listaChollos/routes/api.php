<?php 

use App\Http\Controllers\ApisController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

//esto no sirve, colocar en web.php con el nombre de /api/....

