<footer>
    <p>Portal de Empleo 2026 - Javier Conde Cortes</p>
</footer>