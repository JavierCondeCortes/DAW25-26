@extends('examen.footer')
@extends('examen.nav')

@section('apartado')
    <form action="{{ route('creadoOferta') }}" method="post">
        @csrf
        {{-- debido a que no me funciona tailwind ns porque si siempre suele funcionar, e decidido poner colores que se que van a funcionar --}}
        <div class=" text-red-600">
            @error('titulo')
                <div>
                    {{ $message }}
                </div>
            @enderror
            @error('descripcion')
                <div>
                    {{ $message }}
                </div>
            @enderror
            @error('salario')
                <div>
                    {{ $message }}
                </div>
            @enderror
            @error('tipo_contrato')
                <div>
                    {{ $message }}
                </div>
            @enderror
            @error('fecha_cierre')
                <div>
                    {{ $message }}
                </div>
            @enderror
            @error('empresa_id')
                <div>
                    {{ $message }}
                </div>
            @enderror
        </div>

        <label for="">Titulo</label>
        <input type="text" name="titulo" value="{{ old('titulo') }}">


        <label for="">Descripcion</label>
        <input type="text" name="descripcion" value="{{ old('descripcion') }}">


        <label for="">Salario</label>
        <input type="number" name="salario" value="{{ old('salario') }}">


        <label for="">Tipo de contrato</label>
        <select name="tipo_contrato" id="">
            <option value="Indefinido">Indefinido</option>
            <option value="Temporal">Temporal</option>
            <option value="Frelance">Frelance</option>
            <option value="Prácticas">Practicas</option>
        </select>


        <label for="">Fecha cierre</label>
        <input type="date" name="fecha_cierre" value="{{ old('fecha_cierre') }}">


        <label for="">Empresa</label>
        <select name="empresa_id" id="">
            @foreach ($empresas as $empresa)
                <option value="{{ $empresa->id }}">{{ $empresa->nombre }}</option>
            @endforeach
        </select>


        <input type="submit" value="Crear">
    </form>
@endsection
