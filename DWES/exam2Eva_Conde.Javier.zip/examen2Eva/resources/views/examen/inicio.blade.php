@extends('examen.footer')
@extends('examen.nav')

@section('apartado')
    {{-- estaba pensando como sacar el valor de la opcion y asi poder hacer el filtrado
es por eso lo que no funciona, por el momento --}}

    <form action="{{ route('filtro') }}" method="get">
        <label for="">empresa</label>
        <select name="empresa" id="">
            <option value="">todas</option>
            @foreach ($empresas as $empresa)
                <option name='opcion' value="{{ $empresa->id }}">{{ $empresa->nombre }}</option>
            @endforeach
        </select>

        <label for="">estado</label>
        <select name="estado" id="">
            <option value="">todas</option>
            <option value="activas">activas</option>
            <option value="expiradas">expiradas</option>
        </select>

        <input type="submit" value="Filtrar" disabled>
        <p>deshabilitado por mal funcionamiento</p>
    </form>

    @if (session('mensaje'))
        <div class=' text-green-500'>
            {{ session('mensaje') }}
        </div>
    @endif

    {{-- <p>{{$fecha_actual}}</p> --}}
    <div class="">
        @foreach ($ofertas as $oferta)
            <div class=" bg-gray-500 p-4 ">
                <h2>{{ $oferta->titulo }}</h2>
                <p>{{ $oferta->empresa->nombre }}</p>
                <p>{{ $oferta->salario }}</p>
                <p>{{ $oferta->tipo_contrato }}</p>
                <p>{{ $oferta->fecha_cierre }}</p>
                <p>
                    {{-- he tenido problemas, se que esta es la forma pero me falta convertir $fecha_actual --}}
                    estado:
                    @if ($oferta->fecha_cierre < $fecha_actual)
                        Activo
                    @else
                        Oferta expirada
                    @endif
                </p>
            </div>
        @endforeach
    </div>
    {{ $ofertas->links() }}
@endsection
