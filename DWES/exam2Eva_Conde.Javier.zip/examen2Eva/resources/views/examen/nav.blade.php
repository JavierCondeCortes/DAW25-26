<header>
    <h1>Ofertas de trabajo</h1>
</header>
<nav>
    <a href="{{ route('inicio') }}">Ofertas</a>
    <a href="{{ route('crearOferta') }}">Crear oferta</a>
</nav>

<main>
    @yield('apartado')
</main>
