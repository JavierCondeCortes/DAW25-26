{{-- no interfiere, son pruebas para el filtrado --}}
@extends('examen.footer')
@extends('examen.nav')

@section('apartado')

<form action="" method="get">
    <label for="">empresa</label>
    <select name="empresa" id="">
        <option value="">todas</option>
        @foreach ($empresas as $empresa)
            <option value="{{$empresa->id}}">{{$empresa->nombre}}</option>
        @endforeach
    </select>

    <label for="">estado</label>
    <select name="estado" id="">
        <option value="">todas</option>
        <option value="activas">activas</option>
        <option value="expiradas">expiradas</option>
    </select>

    <input type="submit" value="Filtrar">
</form>

    @if (session('mensaje'))
        <div>
            {{session('mensaje')}};
        </div>
    @endif

    @foreach ($ofertas as $oferta)
        <div>
            <h2>{{$oferta->titulo}}</h2>
            <p>{{$oferta->empresa->nombre}}</p>
            <p>{{$oferta->salario}}</p>
            <p>{{$oferta->tipo_contrato}}</p>
            <p>{{$oferta->fecha_cierre}}</p>
            <p>
                estado: 
                @if ($oferta->fecha_cierre > $fecha_actual)
                    Activo
                @else
                    Oferta expirada
                @endif
            </p>
        </div>
    @endforeach

    {{$ofertas -> links()}}

@endsection

