<?php

namespace App\Http\Controllers;

use App\Models\Empresa;
use App\Models\Oferta;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Date;

class pagesController extends Controller
{
    //OFERTAS
    public function inicioOfertas()
    {
        $ofertas = Oferta::paginate(5);
        $empresas = Empresa::all();
        $fecha_actual = date("YYYY-MM-DD",time());        

        return view('examen.inicio', compact('ofertas', 'empresas','fecha_actual'));
    }

    public function filtro()
    {

        if ($id = '') {
            return view('inicio');
        }
        $ofertas = Oferta::where('empresa_id', $id);
        //si no encuentro la solucion para el estado, no puedo filtrarlo
        // $estado = Oferta::where('fecha_cierre'>date("YYYY-MM-DD",time()));
        $empresas = Empresa::all();

        return view('examen.inicio',compact('ofertas','empresas'));
    }

    public function crearOferta()
    {
        $ofertas = Oferta::all();
        $empresas = Empresa::all();

        return view('examen.formCrear', compact('ofertas', 'empresas'));
    }

    public function creadoOferta(Request $request)
    {
        $request->validate([
            'titulo'        => 'required',
            'descripcion'   => 'required',
            'salario'       => 'required|numeric|min:0',
            'tipo_contrato' => 'required',
            'fecha_cierre'  => 'required',
            'empresa_id'    => 'required',
        ]);

        $newOferta = new Oferta;

        $newOferta->titulo = $request->titulo;
        $newOferta->descripcion = $request->descripcion;
        $newOferta->salario = $request->salario;
        $newOferta->tipo_contrato = $request->tipo_contrato;
        $newOferta->fecha_cierre = $request->fecha_cierre;
        $newOferta->empresa_id = $request->empresa_id;

        $newOferta->save();

        return redirect()->route('inicio')->with('mensaje', 'La oferta fue creada');
    }
}
