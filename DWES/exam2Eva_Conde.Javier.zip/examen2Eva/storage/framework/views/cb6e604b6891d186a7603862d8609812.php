<header>
    <h1>Ofertas de trabajo</h1>
</header>
<nav>
    <a href="<?php echo e(route('inicio')); ?>">Ofertas</a>
    <a href="<?php echo e(route('crearOferta')); ?>">Crear oferta</a>
</nav>

<main>
    <?php echo $__env->yieldContent('apartado'); ?>
</main>
<?php /**PATH C:\Users\javier.concor\Desktop\examenLaravel\examen2Eva\resources\views/examen/nav.blade.php ENDPATH**/ ?>