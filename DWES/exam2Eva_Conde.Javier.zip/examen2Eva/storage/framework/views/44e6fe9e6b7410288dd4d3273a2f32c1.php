



<?php $__env->startSection('apartado'); ?>

<form action="" method="get">
    <label for="">empresa</label>
    <select name="empresa" id="">
        <option value="">todas</option>
        <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($empresa->id); ?>"><?php echo e($empresa->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="">estado</label>
    <select name="estado" id="">
        <option value="">todas</option>
        <option value="activas">activas</option>
        <option value="expiradas">expiradas</option>
    </select>

    <input type="submit" value="Filtrar">
</form>

    <?php if(session('mensaje')): ?>
        <div>
            <?php echo e(session('mensaje')); ?>;
        </div>
    <?php endif; ?>

    <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <h2><?php echo e($oferta->titulo); ?></h2>
            <p><?php echo e($oferta->empresa->nombre); ?></p>
            <p><?php echo e($oferta->salario); ?></p>
            <p><?php echo e($oferta->tipo_contrato); ?></p>
            <p><?php echo e($oferta->fecha_cierre); ?></p>
            <p>
                estado: 
                <?php if($oferta->fecha_cierre > $fecha_actual): ?>
                    Activo
                <?php else: ?>
                    Oferta expirada
                <?php endif; ?>
            </p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($ofertas -> links()); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('examen.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('examen.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\javier.concor\Desktop\examenLaravel\examen2Eva\resources\views/examen/filtro.blade.php ENDPATH**/ ?>