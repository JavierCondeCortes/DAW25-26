<footer>
    <p>Portal de Empleo 2026 - Javier Conde Cortes</p>
</footer><?php /**PATH C:\Users\javier.concor\Desktop\examenLaravel\examen2Eva\resources\views/examen/footer.blade.php ENDPATH**/ ?>