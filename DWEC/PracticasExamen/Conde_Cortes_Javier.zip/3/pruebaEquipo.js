import Equipo from "./claseEquipo.js";

const A = new Equipo("definicion de prueba de grupo",10,10);
A.CodigoId("P");
A.CodigoId("S");
A.calcularFecha(0);
A.calcularFecha(10);