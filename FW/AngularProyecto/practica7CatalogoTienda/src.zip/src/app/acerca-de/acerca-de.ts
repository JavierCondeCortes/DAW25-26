import { Component } from '@angular/core';

@Component({
  selector: 'app-acerca-de',
  imports: [],
  templateUrl: './acerca-de.html',
  styleUrl: './acerca-de.css',
})
export class AcercaDe {

}
