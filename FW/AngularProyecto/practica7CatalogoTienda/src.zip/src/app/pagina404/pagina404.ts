import { Component } from '@angular/core';

@Component({
  selector: 'app-pagina404',
  imports: [],
  templateUrl: './pagina404.html',
  styleUrl: './pagina404.css',
})
export class Pagina404 {

}
