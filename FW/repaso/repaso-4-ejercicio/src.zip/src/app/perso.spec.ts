import { Perso } from './perso';

describe('Perso', () => {
  it('should create an instance', () => {
    expect(new Perso()).toBeTruthy();
  });
});
